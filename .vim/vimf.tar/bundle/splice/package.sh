#!/usr/bin/env bash

hg archive ~/Desktop/splice.zip -I 'doc' -I 'plugin' -I 'autoload' -I 'syntax' -I 'LICENSE.markdown' -I 'README.markdown'
